# -*- coding: utf-8 -*-
"""
Дополнительный синтетический набор к корпусу (дополнение к ТЗ, 02.11.2026) -> corpus/synth_extra/.
Случаи, которых нет в основном корпусе, но которые требуются правилами ТЗ:
  no_target   — у клиента нет договора, к которому относится документ (ожидается: не рекомендация);
  multi3      — документ по трём договорам (ожидается: ручной разбор);
  conflict    — явная ссылка с номером, противоречащим договору (ожидается: разбор с пояснением);
  same_number — одна ссылка без даты, два договора с одинаковым номером (ожидается: альтернативы, разбор).
Документы относятся к тем же клиентам, что и corpus/synth, и сопоставляются с его договорами.
Запуск: python gen_extra.py  (требует gen_synth.py рядом и готовый corpus/synth).
"""
import csv, random
from datetime import timedelta, datetime
from pathlib import Path
import gen_synth as g

g.rnd = random.Random(20261102)
rnd = g.rnd
BASE = Path(__file__).parent / "corpus"
OUT = BASE / "synth_extra"
CL = {c["inn"]: c for c in g.CLIENTS}

def pd(s): return datetime.strptime(s, "%d.%m.%Y").date()

def contracts():
    out = []
    for r in csv.DictReader(open(BASE / "synth" / "documents.csv", encoding="utf-8-sig"), delimiter=";"):
        if r["kind"] != "договор" or r["client_inn"] not in CL: continue
        kind = next(k for k, v in g.SUBJECTS.items() if r["subject"] in v)
        out.append({"id": r["doc_id"], "is_contract": True, "num": r["number"], "date": pd(r["date"]), "subj": r["subject"],
                    "kind": kind, "client": CL[r["client_inn"]], "amount": float(r["amount"]),
                    "cp": {"short": r["cp_name"], "full": r["cp_name"], "inn": r["cp_inn"], "kpp": g.kpp(), "head": g.person(),
                           "root": r["cp_name"]}})
    return out

def doc_rows(cs, d0, share=4):
    rows = []
    for c in cs:
        c["_m"], c["_y"] = d0.month, d0.year
        rows += g.lines_for(c, round(c["amount"] / share, -2))
    return rows

def main():
    OUT.mkdir(parents=True, exist_ok=True)
    C = contracts()
    docs, links, n = [], [], 0
    def put(kind, d, cs, case, expected, hard="", gold=(), text=None):
        nonlocal n
        n += 1; did = f"extra_{n:03d}"; (OUT / did).mkdir(exist_ok=True)
        txt = text or {"акт": lambda: g.t_act(d, cs), "УПД": lambda: g.t_act(d, cs, upd=True), "счёт": lambda: g.t_invoice(d, cs)}[kind]()
        (OUT / did / "doc_01.txt").write_text(txt, encoding="utf-8")
        c = cs[0]
        docs.append({"doc_id": f"{did}/doc_01", "deal_id": did, "source": "synth_extra", "client_inn": c["client"]["inn"], "kind": kind,
                     "number": d["num"], "date": g.dshort(d["date"]), "cp_inn": c["cp"]["inn"], "cp_name": c["cp"]["short"],
                     "amount": f"{sum(q * p for _, q, _, p in d['rows']) * 1.2:.2f}" if "rows" in d else f"{d.get('amount', 0):.2f}",
                     "subject": d.get("subj", ""), "hard_types": hard, "case": case, "expected": expected})
        rel = {"акт": "исполнение", "УПД": "исполнение", "счёт": "основание"}.get(kind)
        for t in gold: links.append({"source": f"{did}/doc_01", "target": t, "type": rel})
        return did

    # 1. no_target: новый контрагент, договора в базе нет
    for i in range(6):
        client = rnd.choice(g.CLIENTS); cp = g.org()
        fake = g.new_contract(client, cp, g.date(2025, 1, 1) + timedelta(days=rnd.randint(0, 300))); fake["kind"] = fake.pop("kindc")
        d0 = fake["date"] + timedelta(days=rnd.randint(20, 60))
        kind = ["акт", "счёт", "акт", "УПД", "счёт", "акт"][i]
        if kind == "УПД": fake["kind"] = "поставка"; fake["subj"] = rnd.choice(g.SUBJECTS["поставка"])
        d = {"num": str(rnd.randint(1, 900)), "date": d0, "rows": doc_rows([fake], d0), "err": {1} if i >= 4 else set()}
        put(kind, d, [fake], "no_target", "не рекомендация")

    # 2. multi3: акт по трём договорам одного клиента
    by_client = {}
    for c in C: by_client.setdefault(c["client"]["inn"], []).append(c)
    pools = [v for v in by_client.values() if len([c for c in v if c["kind"] != "поставка"]) >= 3]
    for i in range(3):
        v = [c for c in rnd.choice(pools) if c["kind"] != "поставка"]
        cs = rnd.sample(v, 3); d0 = max(c["date"] for c in cs) + timedelta(days=rnd.randint(20, 60))
        d = {"num": str(rnd.randint(1, 900)), "date": d0, "rows": doc_rows(cs, d0, 6), "err": {8}}
        put("акт", d, cs, "multi3", "разбор", "8", [c["id"] for c in cs])

    # 3. conflict: верный контрагент и предмет, но номер в ссылке не совпадает ни с одним договором клиента
    for i in range(4):
        c = rnd.choice([c for c in C if c["kind"] != "поставка"])
        nums = {x["num"] for x in by_client[c["client"]["inn"]]}
        wrong = next(s for s in (f"{rnd.randint(100, 999)}/{c['date'].year % 100}" for _ in range(50)) if s not in nums)
        d0 = c["date"] + timedelta(days=rnd.randint(30, 120))
        cc = dict(c, num=wrong)                     # в тексте — ошибочный номер, остальное верно
        d = {"num": str(rnd.randint(1, 900)), "date": d0, "rows": doc_rows([c], d0), "err": set()}
        put(rnd.choice(["акт", "счёт"]), d, [cc], "conflict", "разбор", "2", [c["id"]])

    # 4. same_number: два договора с одинаковым номером (разные годы), ссылка «к договору № X» без даты
    for i in range(2):
        client = rnd.choice(g.CLIENTS); cp = g.org()
        num = f"{rnd.randint(1, 60)}"
        kind = "услуги"; subj = rnd.choice(g.SUBJECTS[kind])
        c1 = g.new_contract(client, cp, g.date(2024, 2, 1) + timedelta(days=rnd.randint(0, 60)), kind=kind, subj=subj, num=num)
        c2 = g.new_contract(client, cp, c1["date"] + timedelta(days=365), kind=kind, subj=subj, num=num)
        ids = []
        for c in (c1, c2):
            c["kind"] = c.pop("kindc")
            did = put("договор", {"num": num, "date": c["date"], "amount": c["amount"], "subj": subj}, [c], "same_number_contract", "—",
                      "9", text=g.t_contract(c))
            ids.append(f"{did}/doc_01")
        d0 = c2["date"] + timedelta(days=40)
        act = {"num": str(rnd.randint(1, 900)), "date": d0, "rows": doc_rows([c2], d0), "err": set()}
        txt = g.t_act(act, [c2]).replace(next(l for l in g.t_act(act, [c2]).splitlines() if l.startswith("Основание")),
                                         f"Основание: к договору № {num}")
        put("акт", act, [c2], "same_number", "разбор", "9", [ids[1]], text=txt)

    for name, rows in (("documents.csv", docs), ("links.csv", links)):
        with open(OUT / name, "w", newline="", encoding="utf-8-sig") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0]), delimiter=";"); w.writeheader(); w.writerows(rows)
    print(f"документов {len(docs)}, связей {len(links)}")

if __name__ == "__main__":
    main()
